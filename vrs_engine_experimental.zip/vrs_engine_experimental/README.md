# Experimental DIY VRS Engine

This is a **real experimental VRS-like engine**. It connects to multiple RTCM base streams,
decodes GPS/Galileo/BeiDou MSM4/MSM7 observations, combines them into a synthetic virtual
reference station, re-encodes synthetic MSM4 RTCM messages, and serves one fake correction
stream to your rover.

It is not professional/survey-grade. It is meant for learning and testing with hobby RTK.

## What it does

- Reads 2-3+ NTRIP base station streams
- Decodes RTCM3 frames and validates CRC24Q
- Decodes 1005/1006 base coordinates
- Decodes GPS/Galileo/BeiDou MSM4 and MSM7 observations:
  - GPS: 1074 / 1077
  - Galileo: 1094 / 1097
  - BeiDou: 1124 / 1127
- Interpolates pseudorange observations to a virtual station
- Aligns carrier phase observations to the selected master base
- Encodes synthetic MSM4:
  - GPS 1074
  - Galileo 1094
  - BeiDou 1124
- Encodes synthetic 1005 for the virtual base
- Serves the output through a simple local NTRIP-like caster
- Can also write the synthetic stream directly to a serial port

## What it does not do yet

- No GLONASS VRS output
- No ephemeris-based geometric correction
- No professional ionosphere/troposphere model
- No true integer ambiguity network fixing
- No RTCM MSM7 output encoder yet; output is MSM4 only
- No guarantee your LC29HEA will RTK FIX from this stream

The carrier phase method is deliberately simple:
it preserves/aligns phase relative to the master base instead of blindly averaging raw
phase ambiguities. This gives the rover a more consistent fake stream than raw averaging,
but it is still experimental.

## Install

Python 3.10+ recommended.

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Linux / Raspberry Pi:

```bash
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Configure

```bash
cp config.example.yaml config.yaml
```

Edit:

- `virtual.lat_deg`
- `virtual.lon_deg`
- `virtual.h_m`
- all base mountpoints
- `engine.master_base`
- output port / serial port

For first test, set the virtual position near your rover starting point.
For relative robotics, it does not have to be surveyed, but it should be stable.

## Run

```bash
python -m vrs_engine.main --config config.yaml
```

You should see base status and output status.

## Connect rover

Configure your rover/NTRIP client to connect to:

```text
host: your computer/Raspberry Pi IP
port: 2102
mountpoint: VRS
username/password: blank
```

Or enable serial output in `config.yaml` and write directly to the LC29HEA correction input port.

## Test order

Do not start by trusting the synthetic stream. Test in this order:

1. Run with 2-3 bases and make sure CRC errors stay near zero.
2. Confirm base coordinates are decoded.
3. Confirm synthetic 1005 and MSM4 are being output.
4. Record the synthetic output to a `.rtcm3` file.
5. Feed the synthetic stream to RTKLIB/BNC if possible.
6. Only then connect the LC29HEA.

## Important

Do **not** feed the original three base streams into the rover. Feed only this engine's output stream.

## Expected results

This may produce:
- DGPS/float improvement
- faster float
- maybe occasional RTK fix
- maybe no improvement if phase alignment is not good enough

This is a research tool. The next upgrades would be:
1. use satellite ephemeris and geometric range correction
2. implement undifferenced network residual modeling
3. implement cycle slip tracking
4. encode MSM7 instead of MSM4
5. add true ambiguity-fixed network phase handling
