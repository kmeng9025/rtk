# External tools that help

## 1. RTKLIB / RTKLIB demo5

Use RTKLIB tools to inspect the generated stream.

Useful tools:

- `str2str`: relay/record streams
- `convbin`: convert RTCM/RINEX
- `rtkplot`: inspect observations
- `rtkrcv`: real-time solution testing

Example record:

```bash
str2str -in ntrip://localhost:2102/VRS -out file://synthetic.rtcm3
```

Example convert:

```bash
convbin synthetic.rtcm3 -r rtcm3 -o synthetic.obs
```

## 2. BKG BNC

BNC is great for seeing the actual satellite/signal observations inside streams.

Use it to compare:

- base A
- base B
- base C
- synthetic VRS output

## 3. SNIP

Optional. You can use SNIP as a proper NTRIP caster, but this package already has a tiny caster.

# Engineering upgrades

This prototype combines bases without ephemeris. The next major upgrade is:

```text
Use broadcast ephemeris -> compute satellite positions -> remove geometric range from each base -> interpolate residuals -> add geometry back at virtual station
```

That would be much closer to true VRS.

After that:

```text
phase ambiguity network alignment
cycle slip tracking
MSM7 output
GLONASS + 1230 handling
SSR/PPP-style corrections
```
