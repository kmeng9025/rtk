\
from __future__ import annotations

class BitReader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def remaining(self) -> int:
        return len(self.data) * 8 - self.pos

    def u(self, n: int) -> int:
        val = 0
        for _ in range(n):
            if self.pos >= len(self.data) * 8:
                raise EOFError("bit read past end")
            byte_i = self.pos // 8
            bit_i = 7 - (self.pos % 8)
            val = (val << 1) | ((self.data[byte_i] >> bit_i) & 1)
            self.pos += 1
        return val

    def s(self, n: int) -> int:
        val = self.u(n)
        sign = 1 << (n - 1)
        if val & sign:
            val -= 1 << n
        return val


class BitWriter:
    def __init__(self):
        self.bits: list[int] = []

    def u(self, val: int, n: int) -> None:
        if val < 0 or val >= (1 << n):
            raise ValueError(f"unsigned value {val} does not fit {n} bits")
        for i in range(n - 1, -1, -1):
            self.bits.append((val >> i) & 1)

    def s(self, val: int, n: int) -> None:
        lo = -(1 << (n - 1))
        hi = (1 << (n - 1)) - 1
        if val < lo or val > hi:
            raise ValueError(f"signed value {val} does not fit {n} bits")
        if val < 0:
            val = (1 << n) + val
        self.u(val, n)

    def bytes(self) -> bytes:
        out = bytearray((len(self.bits) + 7) // 8)
        for i, bit in enumerate(self.bits):
            if bit:
                out[i // 8] |= 1 << (7 - (i % 8))
        return bytes(out)
