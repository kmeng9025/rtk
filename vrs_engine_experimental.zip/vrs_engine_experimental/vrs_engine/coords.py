\
from __future__ import annotations
import math
from dataclasses import dataclass

A_WGS84 = 6378137.0
F_WGS84 = 1.0 / 298.257223563
E2_WGS84 = F_WGS84 * (2 - F_WGS84)

@dataclass
class ECEF:
    x: float
    y: float
    z: float

@dataclass
class LLA:
    lat_deg: float
    lon_deg: float
    h_m: float

def lla_to_ecef(lat_deg: float, lon_deg: float, h_m: float) -> ECEF:
    lat = math.radians(lat_deg)
    lon = math.radians(lon_deg)
    sinp = math.sin(lat)
    cosp = math.cos(lat)
    n = A_WGS84 / math.sqrt(1 - E2_WGS84 * sinp * sinp)
    x = (n + h_m) * cosp * math.cos(lon)
    y = (n + h_m) * cosp * math.sin(lon)
    z = (n * (1 - E2_WGS84) + h_m) * sinp
    return ECEF(x, y, z)

def ecef_to_lla(ecef: ECEF) -> LLA:
    x, y, z = ecef.x, ecef.y, ecef.z
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1 - E2_WGS84))
    for _ in range(8):
        sinp = math.sin(lat)
        n = A_WGS84 / math.sqrt(1 - E2_WGS84 * sinp * sinp)
        h = p / math.cos(lat) - n
        lat = math.atan2(z, p * (1 - E2_WGS84 * n / (n + h)))
    sinp = math.sin(lat)
    n = A_WGS84 / math.sqrt(1 - E2_WGS84 * sinp * sinp)
    h = p / math.cos(lat) - n
    return LLA(math.degrees(lat), math.degrees(lon), h)

def ecef_to_enu(ecef: ECEF, origin: LLA) -> tuple[float, float, float]:
    o = lla_to_ecef(origin.lat_deg, origin.lon_deg, origin.h_m)
    dx, dy, dz = ecef.x - o.x, ecef.y - o.y, ecef.z - o.z
    lat = math.radians(origin.lat_deg)
    lon = math.radians(origin.lon_deg)
    slat, clat = math.sin(lat), math.cos(lat)
    slon, clon = math.sin(lon), math.cos(lon)
    east = -slon * dx + clon * dy
    north = -slat * clon * dx - slat * slon * dy + clat * dz
    up = clat * clon * dx + clat * slon * dy + slat * dz
    return east, north, up
