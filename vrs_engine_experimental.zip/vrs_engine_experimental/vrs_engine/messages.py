\
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, Optional, List
import time
from .bits import BitReader, BitWriter
from .rtcm import frame_payload
from .coords import ECEF

# Supported constellation MSM mapping. Output is MSM4.
MSM_INPUT_TO_OUTPUT = {
    1074: 1074, 1077: 1074,   # GPS
    1094: 1094, 1097: 1094,   # Galileo
    1124: 1124, 1127: 1124,   # BeiDou
}
SUPPORTED_MSM = set(MSM_INPUT_TO_OUTPUT.keys())

@dataclass
class StationCoord:
    station_id: int
    ecef: ECEF
    has_height: bool = False
    ant_height_m: float = 0.0

@dataclass
class CellObs:
    pseudorange_ms: float
    phase_ms: float
    lock: int = 0
    half_cycle: int = 0
    cnr_dbhz: float = 0.0
    phase_rate_mps: float = 0.0

@dataclass
class MsmObs:
    msg_type: int
    out_msg_type: int
    station_id: int
    epoch_ms: int
    multiple_message: int
    sats: List[int]
    sigs: List[int]
    cells: Dict[Tuple[int, int], CellObs] = field(default_factory=dict)
    recv_time: float = field(default_factory=time.time)

def decode_1005_1006(payload: bytes, msg_type: int) -> Optional[StationCoord]:
    try:
        br = BitReader(payload)
        mt = br.u(12)
        if mt not in (1005, 1006):
            return None
        sid = br.u(12)
        _itrf = br.u(6)
        _gps = br.u(1)
        _glo = br.u(1)
        _gal = br.u(1)
        _ref = br.u(1)
        x = br.s(38) * 0.0001
        _osc = br.u(1)
        _res = br.u(1)
        y = br.s(38) * 0.0001
        _qci = br.u(2)
        z = br.s(38) * 0.0001
        h = 0.0
        has_h = False
        if mt == 1006 and br.remaining() >= 16:
            h = br.u(16) * 0.0001
            has_h = True
        return StationCoord(sid, ECEF(x, y, z), has_h, h)
    except Exception:
        return None

def encode_1005(station_id: int, ecef: ECEF) -> bytes:
    bw = BitWriter()
    bw.u(1005, 12)
    bw.u(station_id & 0xFFF, 12)
    bw.u(0, 6)       # ITRF realization year, unknown
    bw.u(1, 1)       # GPS indicator
    bw.u(1, 1)       # GLONASS indicator
    bw.u(1, 1)       # Galileo indicator
    bw.u(0, 1)       # reference station indicator
    bw.s(int(round(ecef.x / 0.0001)), 38)
    bw.u(0, 1)       # oscillator indicator
    bw.u(0, 1)       # reserved
    bw.s(int(round(ecef.y / 0.0001)), 38)
    bw.u(0, 2)       # quarter-cycle indicator unknown
    bw.s(int(round(ecef.z / 0.0001)), 38)
    return frame_payload(bw.bytes())

def _mask_indices(mask: int, nbits: int) -> List[int]:
    # RTCM MSM masks are MSB first. Satellite/signal IDs are 1-based.
    ids = []
    for i in range(nbits):
        bit = (mask >> (nbits - 1 - i)) & 1
        if bit:
            ids.append(i + 1)
    return ids

def decode_msm(payload: bytes, msg_type: int) -> Optional[MsmObs]:
    if msg_type not in SUPPORTED_MSM:
        return None
    try:
        br = BitReader(payload)
        mt = br.u(12)
        sid = br.u(12)
        epoch = br.u(30)
        multi = br.u(1)
        _iods = br.u(3)
        _reserved = br.u(7)
        _clock_steering = br.u(2)
        _ext_clock = br.u(2)
        _smooth = br.u(1)
        _smooth_int = br.u(3)
        sat_mask = br.u(64)
        sig_mask = br.u(32)
        sats = _mask_indices(sat_mask, 64)
        sigs = _mask_indices(sig_mask, 32)
        nsat, nsig = len(sats), len(sigs)
        if nsat == 0 or nsig == 0:
            return None
        cell_bits = [br.u(1) for _ in range(nsat * nsig)]
        cell_pairs: List[Tuple[int, int]] = []
        k = 0
        for sat in sats:
            for sig in sigs:
                if cell_bits[k]:
                    cell_pairs.append((sat, sig))
                k += 1

        level = msg_type % 10
        rough_int: Dict[int, int] = {}
        rough_mod: Dict[int, int] = {}
        phase_rate: Dict[int, int] = {}

        for sat in sats:
            rough_int[sat] = br.u(8)

        if level in (5, 7):
            for sat in sats:
                _ext_info = br.u(4)

        for sat in sats:
            rough_mod[sat] = br.u(10)

        if level in (5, 7):
            for sat in sats:
                phase_rate[sat] = br.s(14)

        cells: Dict[Tuple[int, int], CellObs] = {}

        if level in (4, 5):
            fine_pr = [br.s(15) for _ in cell_pairs]
            fine_ph = [br.s(22) for _ in cell_pairs]
            locks = [br.u(4) for _ in cell_pairs]
            halfs = [br.u(1) for _ in cell_pairs]
            cnrs = [br.u(6) for _ in cell_pairs]
            for idx, pair in enumerate(cell_pairs):
                sat, sig = pair
                ri = rough_int[sat]
                if ri == 255:
                    continue
                # Invalid signed min values are skipped.
                if fine_pr[idx] == -(1 << 14) or fine_ph[idx] == -(1 << 21):
                    continue
                rough_ms = ri + rough_mod[sat] / 1024.0
                pr_ms = rough_ms + fine_pr[idx] * (2.0 ** -24)
                ph_ms = rough_ms + fine_ph[idx] * (2.0 ** -29)
                cells[pair] = CellObs(
                    pseudorange_ms=pr_ms,
                    phase_ms=ph_ms,
                    lock=locks[idx],
                    half_cycle=halfs[idx],
                    cnr_dbhz=float(cnrs[idx]),
                    phase_rate_mps=float(phase_rate.get(sat, 0)),
                )
        elif level in (6, 7):
            fine_pr = [br.s(20) for _ in cell_pairs]
            fine_ph = [br.s(24) for _ in cell_pairs]
            locks = [br.u(10) for _ in cell_pairs]
            halfs = [br.u(1) for _ in cell_pairs]
            cnrs = [br.u(10) for _ in cell_pairs]
            fine_rate = [br.s(15) for _ in cell_pairs]
            for idx, pair in enumerate(cell_pairs):
                sat, sig = pair
                ri = rough_int[sat]
                if ri == 255:
                    continue
                if fine_pr[idx] == -(1 << 19) or fine_ph[idx] == -(1 << 23):
                    continue
                rough_ms = ri + rough_mod[sat] / 1024.0
                pr_ms = rough_ms + fine_pr[idx] * (2.0 ** -29)
                ph_ms = rough_ms + fine_ph[idx] * (2.0 ** -31)
                cells[pair] = CellObs(
                    pseudorange_ms=pr_ms,
                    phase_ms=ph_ms,
                    lock=locks[idx],
                    half_cycle=halfs[idx],
                    cnr_dbhz=cnrs[idx] / 16.0,
                    phase_rate_mps=float(phase_rate.get(sat, 0)) + fine_rate[idx] * 0.0001,
                )
        else:
            return None

        if not cells:
            return None
        used_sats = sorted({s for s, _ in cells})
        used_sigs = sorted({g for _, g in cells})
        return MsmObs(
            msg_type=msg_type,
            out_msg_type=MSM_INPUT_TO_OUTPUT[msg_type],
            station_id=sid,
            epoch_ms=epoch,
            multiple_message=multi,
            sats=used_sats,
            sigs=used_sigs,
            cells=cells,
        )
    except Exception:
        return None

def _make_mask(ids: List[int], nbits: int) -> int:
    val = 0
    for i in range(nbits):
        obj_id = i + 1
        val <<= 1
        if obj_id in ids:
            val |= 1
    return val

def _clip_signed(v: int, n: int) -> int:
    lo = -(1 << (n - 1)) + 1  # reserve most-negative as invalid
    hi = (1 << (n - 1)) - 1
    return min(max(v, lo), hi)

def encode_msm4(obs: MsmObs, station_id: int) -> bytes:
    """
    Encodes synthetic MSM4 for GPS/Galileo/BeiDou.
    """
    out_mt = obs.out_msg_type
    sats = sorted({s for s, _ in obs.cells.keys()})
    sigs = sorted({g for _, g in obs.cells.keys()})
    if not sats or not sigs:
        raise ValueError("no cells to encode")

    cell_pairs: List[Tuple[int, int]] = []
    for sat in sats:
        for sig in sigs:
            if (sat, sig) in obs.cells:
                cell_pairs.append((sat, sig))

    bw = BitWriter()
    bw.u(out_mt, 12)
    bw.u(station_id & 0xFFF, 12)
    bw.u(int(obs.epoch_ms) & ((1 << 30) - 1), 30)
    bw.u(0, 1)  # multiple message bit
    bw.u(0, 3)  # issue of data station
    bw.u(0, 7)  # reserved
    bw.u(0, 2)  # clock steering
    bw.u(0, 2)  # external clock
    bw.u(0, 1)  # smoothing
    bw.u(0, 3)  # smoothing interval
    bw.u(_make_mask(sats, 64), 64)
    bw.u(_make_mask(sigs, 32), 32)

    for sat in sats:
        for sig in sigs:
            bw.u(1 if (sat, sig) in obs.cells else 0, 1)

    rough_ms_by_sat: Dict[int, float] = {}
    rough_int_by_sat: Dict[int, int] = {}
    rough_mod_by_sat: Dict[int, int] = {}

    for sat in sats:
        # Use the first cell pseudorange as satellite rough range.
        vals = [obs.cells[(sat, sig)].pseudorange_ms for sig in sigs if (sat, sig) in obs.cells]
        ref = vals[0]
        if ref < 0:
            ref = 0
        ri = int(ref)
        if ri >= 255:
            ri = 254
        rem = ref - ri
        rm = int(round(rem * 1024.0))
        if rm >= 1024:
            rm = 0
            ri += 1
            if ri >= 255:
                ri = 254
        rough_int_by_sat[sat] = ri
        rough_mod_by_sat[sat] = rm
        rough_ms_by_sat[sat] = ri + rm / 1024.0

    for sat in sats:
        bw.u(rough_int_by_sat[sat], 8)
    for sat in sats:
        bw.u(rough_mod_by_sat[sat], 10)

    fine_pr_vals = []
    fine_ph_vals = []
    locks = []
    halfs = []
    cnrs = []
    for pair in cell_pairs:
        sat, sig = pair
        c = obs.cells[pair]
        rough = rough_ms_by_sat[sat]
        fine_pr = int(round((c.pseudorange_ms - rough) / (2.0 ** -24)))
        fine_ph = int(round((c.phase_ms - rough) / (2.0 ** -29)))
        fine_pr_vals.append(_clip_signed(fine_pr, 15))
        fine_ph_vals.append(_clip_signed(fine_ph, 22))
        # lock time is hard to synthesize correctly. Use small but nonzero value.
        locks.append(min(max(int(c.lock), 0), 15))
        halfs.append(1 if c.half_cycle else 0)
        cnrs.append(min(max(int(round(c.cnr_dbhz)), 0), 63))

    for v in fine_pr_vals:
        bw.s(v, 15)
    for v in fine_ph_vals:
        bw.s(v, 22)
    for v in locks:
        bw.u(v, 4)
    for v in halfs:
        bw.u(v, 1)
    for v in cnrs:
        bw.u(v, 6)

    return frame_payload(bw.bytes())
