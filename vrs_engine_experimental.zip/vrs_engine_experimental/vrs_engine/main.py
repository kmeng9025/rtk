\
from __future__ import annotations
import argparse, threading, queue, time
from pathlib import Path
import yaml

from .coords import ECEF, LLA, lla_to_ecef
from .rtcm import RtcmFramer
from .ntrip import NtripClient, NtripConfig
from .messages import decode_1005_1006, decode_msm, encode_1005, encode_msm4, SUPPORTED_MSM
from .combiner import VrsCombiner, EngineConfig
from .output import OutputBus, SimpleNtripCaster

class Event:
    def __init__(self, base: str, kind: str, data):
        self.base = base
        self.kind = kind
        self.data = data

def read_yaml(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def input_worker(base_cfg, global_cfg, q: queue.Queue, output_dir: Path):
    ncfg = NtripConfig(
        name=base_cfg["name"],
        host=base_cfg["host"],
        port=int(base_cfg.get("port", 2101)),
        mountpoint=base_cfg["mountpoint"],
        username=str(base_cfg.get("username", "") or ""),
        password=str(base_cfg.get("password", "") or ""),
        send_gga=bool(base_cfg.get("send_gga", False)),
    )
    client = NtripClient(
        ncfg,
        rover_gga=global_cfg.get("input_ntrip", {}).get("rover_gga", "") or "",
        reconnect_delay=float(global_cfg.get("input_ntrip", {}).get("reconnect_delay_sec", 3)),
    )
    framer = RtcmFramer(validate_crc=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / f"{ncfg.name}_{time.strftime('%Y%m%d_%H%M%S')}.rtcm3"
    q.put(Event(ncfg.name, "log", str(log_path)))
    with open(log_path, "ab", buffering=0) as logf:
        for chunk in client.chunks_forever():
            logf.write(chunk)
            q.put(Event(ncfg.name, "bytes", len(chunk)))
            frames = framer.push(chunk)
            if framer.crc_bad:
                q.put(Event(ncfg.name, "crc_bad", framer.crc_bad))
                framer.crc_bad = 0
            if framer.discarded:
                q.put(Event(ncfg.name, "discarded", framer.discarded))
                framer.discarded = 0
            for fr in frames:
                q.put(Event(ncfg.name, "frame", fr))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = read_yaml(args.config)

    outdir = Path(cfg.get("output_dir", "logs"))
    vcfg = cfg.get("virtual", {})
    virtual_lla = LLA(float(vcfg["lat_deg"]), float(vcfg["lon_deg"]), float(vcfg.get("h_m", 0.0)))
    virtual_ecef = lla_to_ecef(virtual_lla.lat_deg, virtual_lla.lon_deg, virtual_lla.h_m)

    ecfg_raw = cfg.get("engine", {})
    ecfg = EngineConfig(
        master_base=ecfg_raw["master_base"],
        min_bases=int(ecfg_raw.get("min_bases", 2)),
        max_obs_age_sec=float(ecfg_raw.get("max_obs_age_sec", 2.5)),
        max_epoch_diff_ms=int(ecfg_raw.get("max_epoch_diff_ms", 1200)),
        weighting=str(ecfg_raw.get("weighting", "idw")),
        idw_power=float(ecfg_raw.get("idw_power", 2.0)),
    )
    enabled_types = set(int(x) for x in ecfg_raw.get("enabled_message_types", list(SUPPORTED_MSM)))
    emit_1005_interval = float(ecfg_raw.get("emit_1005_interval_sec", 5))
    combiner = VrsCombiner(ecfg, virtual_lla)

    bus = OutputBus()
    synth_log = outdir / f"synthetic_vrs_{time.strftime('%Y%m%d_%H%M%S')}.rtcm3"
    outdir.mkdir(parents=True, exist_ok=True)
    bus.attach_file(str(synth_log))
    print(f"[output] synthetic stream log: {synth_log}", flush=True)

    serial_cfg = cfg.get("output", {}).get("serial", {}) or {}
    if serial_cfg.get("enabled", False):
        bus.attach_serial(serial_cfg["port"], int(serial_cfg.get("baud", 115200)))
        print(f"[output] serial enabled: {serial_cfg['port']} @ {serial_cfg.get('baud', 115200)}", flush=True)

    def on_rover_gga(gga):
        if vcfg.get("mode", "fixed") == "from_rover_gga":
            lla = LLA(gga.lat_deg, gga.lon_deg, gga.alt_m)
            combiner.set_virtual_lla(lla)
            print(f"[virtual] updated from rover GGA: {lla.lat_deg:.8f}, {lla.lon_deg:.8f}, {lla.h_m:.2f}", flush=True)

    caster_cfg = cfg.get("output", {}).get("ntrip_caster", {}) or {}
    if caster_cfg.get("enabled", True):
        caster = SimpleNtripCaster(
            caster_cfg.get("host", "0.0.0.0"),
            int(caster_cfg.get("port", 2102)),
            caster_cfg.get("mountpoint", "VRS"),
            bus,
            gga_callback=on_rover_gga,
        )
        caster.start()

    q: queue.Queue = queue.Queue()

    # Preload fallback base coordinates.
    for b in cfg.get("bases", []):
        name = b["name"]
        if all(k in b for k in ("ecef_x_m", "ecef_y_m", "ecef_z_m")):
            combiner.update_base_coord(name, ECEF(float(b["ecef_x_m"]), float(b["ecef_y_m"]), float(b["ecef_z_m"])), 0)
            print(f"[{name}] using configured ECEF coordinates", flush=True)

    for b in cfg.get("bases", []):
        threading.Thread(target=input_worker, args=(b, cfg, q, outdir), daemon=True).start()

    # Status counters
    last_status = time.time()
    last_1005 = 0.0
    stats = {}
    outputs = 0

    def emit_1005():
        # station ID 999 by default for virtual base
        frame = encode_1005(999, combiner.virtual_ecef)
        bus.publish(frame)

    emit_1005()

    while True:
        try:
            ev = q.get(timeout=0.5)
        except queue.Empty:
            ev = None

        now = time.time()
        if now - last_1005 >= emit_1005_interval:
            emit_1005()
            last_1005 = now

        if ev is not None:
            st = stats.setdefault(ev.base, {"bytes":0,"frames":0,"crc":0,"disc":0,"coord":False,"msm":{}})
            if ev.kind == "log":
                print(f"[{ev.base}] logging {ev.data}", flush=True)
            elif ev.kind == "bytes":
                st["bytes"] += int(ev.data)
            elif ev.kind == "crc_bad":
                st["crc"] += int(ev.data)
            elif ev.kind == "discarded":
                st["disc"] += int(ev.data)
            elif ev.kind == "frame":
                fr = ev.data
                st["frames"] += 1
                if fr.msg_type in (1005, 1006):
                    c = decode_1005_1006(fr.payload, fr.msg_type)
                    if c:
                        combiner.update_base_coord(ev.base, c.ecef, c.station_id)
                        st["coord"] = True
                if fr.msg_type in enabled_types:
                    obs = decode_msm(fr.payload, fr.msg_type)
                    if obs:
                        combiner.update_obs(ev.base, obs)
                        st["msm"][obs.out_msg_type] = st["msm"].get(obs.out_msg_type, 0) + 1

                        # Trigger synthesis when master updates.
                        if ev.base == ecfg.master_base:
                            syn = combiner.synthesize_for_type(obs.out_msg_type)
                            if syn:
                                try:
                                    out_frame = encode_msm4(syn, station_id=999)
                                    bus.publish(out_frame)
                                    outputs += 1
                                except Exception as e:
                                    print(f"[synth] encode error {obs.out_msg_type}: {e}", flush=True)

        if now - last_status > 5:
            print("\\n--- VRS status ---", flush=True)
            print(f"virtual: {combiner.virtual_lla.lat_deg:.8f}, {combiner.virtual_lla.lon_deg:.8f}, {combiner.virtual_lla.h_m:.2f} m; outputs={outputs}", flush=True)
            for name, st in sorted(stats.items()):
                bstate = combiner.bases.get(name)
                has_coord = bstate is not None and bstate.ecef is not None
                print(f"{name}: bytes={st['bytes']} frames={st['frames']} crc_bad={st['crc']} disc={st['disc']} coord={has_coord} msm={st['msm']}", flush=True)
            last_status = now

if __name__ == "__main__":
    main()
