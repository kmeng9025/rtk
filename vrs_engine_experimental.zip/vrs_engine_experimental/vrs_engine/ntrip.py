\
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterator, Optional
import base64, socket, time

@dataclass
class NtripConfig:
    name: str
    host: str
    port: int
    mountpoint: str
    username: str = ""
    password: str = ""
    send_gga: bool = False

class NtripClient:
    def __init__(self, cfg: NtripConfig, rover_gga: str = "", timeout: float = 15, reconnect_delay: float = 3):
        self.cfg = cfg
        self.rover_gga = rover_gga.strip()
        self.timeout = timeout
        self.reconnect_delay = reconnect_delay
        self.sock: Optional[socket.socket] = None

    def _auth(self) -> str:
        if self.cfg.username or self.cfg.password:
            token = base64.b64encode(f"{self.cfg.username}:{self.cfg.password}".encode()).decode()
            return f"Authorization: Basic {token}\r\n"
        return ""

    def connect(self) -> socket.socket:
        mount = self.cfg.mountpoint
        if not mount.startswith("/"):
            mount = "/" + mount
        s = socket.create_connection((self.cfg.host, int(self.cfg.port)), timeout=self.timeout)
        s.settimeout(self.timeout)
        req = (
            f"GET {mount} HTTP/1.1\r\n"
            f"Host: {self.cfg.host}:{self.cfg.port}\r\n"
            "Ntrip-Version: Ntrip/2.0\r\n"
            "User-Agent: ExperimentalVRS/0.2\r\n"
            f"{self._auth()}"
            "Connection: close\r\n\r\n"
        )
        s.sendall(req.encode("ascii"))
        header = bytearray()
        while b"\r\n\r\n" not in header and len(header) < 8192:
            b = s.recv(1)
            if not b:
                raise ConnectionError("closed before NTRIP header")
            header.extend(b)
        first = header.decode("latin1", errors="replace").splitlines()[0]
        if "200" not in first and "ICY" not in first:
            raise ConnectionError(f"{self.cfg.name} rejected: {first}")
        s.settimeout(1.0)
        self.sock = s
        return s

    def send_gga(self) -> None:
        if self.sock and self.rover_gga:
            line = self.rover_gga
            if not line.endswith("\r\n"):
                line += "\r\n"
            self.sock.sendall(line.encode("ascii", errors="ignore"))

    def chunks_forever(self, chunk_size: int = 4096, gga_interval: float = 5.0) -> Iterator[bytes]:
        while True:
            try:
                s = self.connect()
                last_gga = 0.0
                while True:
                    now = time.time()
                    if self.cfg.send_gga and self.rover_gga and now - last_gga > gga_interval:
                        self.send_gga()
                        last_gga = now
                    try:
                        data = s.recv(chunk_size)
                    except socket.timeout:
                        continue
                    if not data:
                        raise ConnectionError("NTRIP stream ended")
                    yield data
            except Exception as e:
                print(f"[{self.cfg.name}] reconnect after error: {e}", flush=True)
                try:
                    if self.sock:
                        self.sock.close()
                except Exception:
                    pass
                time.sleep(self.reconnect_delay)
