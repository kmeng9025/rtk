\
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, Optional, List
import math, time
from .coords import ECEF, LLA, ecef_to_lla, ecef_to_enu, lla_to_ecef
from .messages import MsmObs, CellObs

@dataclass
class BaseState:
    name: str
    ecef: Optional[ECEF] = None
    station_id: int = 0
    last_obs: Dict[int, MsmObs] = field(default_factory=dict)

@dataclass
class EngineConfig:
    master_base: str
    min_bases: int = 2
    max_obs_age_sec: float = 2.5
    max_epoch_diff_ms: int = 1200
    weighting: str = "idw"
    idw_power: float = 2.0

class VrsCombiner:
    """
    Experimental observation-domain network combiner.

    Phase handling:
    - pseudorange is spatially interpolated
    - carrier phase is aligned to master to avoid raw averaging of unrelated ambiguities
    """
    def __init__(self, cfg: EngineConfig, virtual_lla: LLA):
        self.cfg = cfg
        self.virtual_lla = virtual_lla
        self.virtual_ecef = lla_to_ecef(virtual_lla.lat_deg, virtual_lla.lon_deg, virtual_lla.h_m)
        self.bases: Dict[str, BaseState] = {}
        # key = (msg_out, sat, sig, base_name), value = phase ambiguity offset relative to master
        self.phase_offsets: Dict[Tuple[int, int, int, str], float] = {}

    def set_virtual_lla(self, lla: LLA) -> None:
        self.virtual_lla = lla
        self.virtual_ecef = lla_to_ecef(lla.lat_deg, lla.lon_deg, lla.h_m)

    def update_base_coord(self, name: str, ecef: ECEF, station_id: int = 0) -> None:
        st = self.bases.setdefault(name, BaseState(name))
        st.ecef = ecef
        if station_id:
            st.station_id = station_id

    def update_obs(self, name: str, obs: MsmObs) -> None:
        st = self.bases.setdefault(name, BaseState(name))
        st.last_obs[obs.out_msg_type] = obs

    def _weights(self, names: List[str]) -> Dict[str, float]:
        # ENU relative to virtual station.
        distances = {}
        for n in names:
            ecef = self.bases[n].ecef
            if ecef is None:
                continue
            e, no, _u = ecef_to_enu(ecef, self.virtual_lla)
            d = max(math.hypot(e, no), 1.0)
            distances[n] = d
        if not distances:
            return {}
        if self.cfg.weighting == "barycentric" and len(distances) == 3:
            # 2D barycentric weights for virtual point (0,0) in triangle of base ENU points.
            pts = []
            for n in distances:
                ecef = self.bases[n].ecef
                e, no, _ = ecef_to_enu(ecef, self.virtual_lla)
                pts.append((n, e, no))
            (n1,x1,y1),(n2,x2,y2),(n3,x3,y3) = pts
            det = (y2-y3)*(x1-x3)+(x3-x2)*(y1-y3)
            if abs(det) > 1e-9:
                l1 = ((y2-y3)*(0-x3)+(x3-x2)*(0-y3))/det
                l2 = ((y3-y1)*(0-x3)+(x1-x3)*(0-y3))/det
                l3 = 1-l1-l2
                ws = {n1:l1,n2:l2,n3:l3}
                # If outside triangle, fall back to IDW to avoid extreme extrapolation.
                if all(-0.25 <= w <= 1.25 for w in ws.values()):
                    s = sum(ws.values())
                    return {k:v/s for k,v in ws.items()}
        weights = {n: 1.0 / (d ** self.cfg.idw_power) for n, d in distances.items()}
        s = sum(weights.values())
        return {n: w / s for n, w in weights.items()}

    def synthesize_for_type(self, out_msg_type: int) -> Optional[MsmObs]:
        now = time.time()
        master_name = self.cfg.master_base
        if master_name not in self.bases:
            return None
        master_obs = self.bases[master_name].last_obs.get(out_msg_type)
        if master_obs is None:
            return None

        candidates = []
        for name, st in self.bases.items():
            obs = st.last_obs.get(out_msg_type)
            if obs is None or st.ecef is None:
                continue
            if now - obs.recv_time > self.cfg.max_obs_age_sec:
                continue
            # handle GPS week rollover-like differences by just checking simple diff here
            if abs(int(obs.epoch_ms) - int(master_obs.epoch_ms)) > self.cfg.max_epoch_diff_ms:
                continue
            candidates.append(name)

        if master_name not in candidates:
            return None
        if len(candidates) < self.cfg.min_bases:
            return None

        weights = self._weights(candidates)
        if not weights:
            return None

        # Build cells that exist in at least min_bases and in master.
        all_cells = set()
        for n in candidates:
            all_cells |= set(self.bases[n].last_obs[out_msg_type].cells.keys())

        out_cells: Dict[Tuple[int,int], CellObs] = {}
        for pair in sorted(all_cells):
            if pair not in master_obs.cells:
                continue
            available = [n for n in candidates if pair in self.bases[n].last_obs[out_msg_type].cells]
            if len(available) < self.cfg.min_bases:
                continue

            # renormalize weights for availability
            sw = sum(weights.get(n, 0.0) for n in available)
            if sw <= 0:
                continue
            wnorm = {n: weights[n] / sw for n in available}
            sat, sig = pair
            master_cell = master_obs.cells[pair]

            # Pseudorange is directly interpolated in milliseconds.
            pr_v = sum(wnorm[n] * self.bases[n].last_obs[out_msg_type].cells[pair].pseudorange_ms for n in available)

            # Align phase ambiguities to master. Store a constant offset per base/sat/sig/msg.
            aligned_phase_sum = 0.0
            for n in available:
                cell = self.bases[n].last_obs[out_msg_type].cells[pair]
                if n == master_name:
                    aligned = cell.phase_ms
                else:
                    key = (out_msg_type, sat, sig, n)
                    # Offset aligns (L_i - P_i) to (L_master - P_master).
                    current_offset = (cell.phase_ms - cell.pseudorange_ms) - (master_cell.phase_ms - master_cell.pseudorange_ms)
                    if key not in self.phase_offsets:
                        self.phase_offsets[key] = current_offset
                    # Very crude cycle-slip/jump guard: if the offset jumps by >0.005 ms (~1500 m), reset.
                    if abs(current_offset - self.phase_offsets[key]) > 0.005:
                        self.phase_offsets[key] = current_offset
                    aligned = cell.phase_ms - self.phase_offsets[key]
                aligned_phase_sum += wnorm[n] * aligned

            cnr = sum(wnorm[n] * self.bases[n].last_obs[out_msg_type].cells[pair].cnr_dbhz for n in available)
            out_cells[pair] = CellObs(
                pseudorange_ms=pr_v,
                phase_ms=aligned_phase_sum,
                lock=min(master_cell.lock, 15),
                half_cycle=master_cell.half_cycle,
                cnr_dbhz=cnr,
                phase_rate_mps=master_cell.phase_rate_mps,
            )

        if not out_cells:
            return None

        sats = sorted({s for s, _ in out_cells})
        sigs = sorted({g for _, g in out_cells})
        return MsmObs(
            msg_type=out_msg_type,
            out_msg_type=out_msg_type,
            station_id=999,
            epoch_ms=master_obs.epoch_ms,
            multiple_message=0,
            sats=sats,
            sigs=sigs,
            cells=out_cells,
            recv_time=now,
        )
