\
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass
class GGA:
    lat_deg: float
    lon_deg: float
    alt_m: float

def _nmea_deg(raw: str, hemi: str) -> Optional[float]:
    if not raw or not hemi:
        return None
    try:
        v = float(raw)
        deg = int(v // 100)
        minutes = v - deg * 100
        out = deg + minutes / 60.0
        if hemi in ("S", "W"):
            out = -out
        return out
    except Exception:
        return None

def parse_gga(line: str) -> Optional[GGA]:
    line = line.strip()
    if not ("GGA" in line[:8]):
        return None
    if "*" in line:
        line = line.split("*", 1)[0]
    p = line.split(",")
    if len(p) < 10:
        return None
    lat = _nmea_deg(p[2], p[3])
    lon = _nmea_deg(p[4], p[5])
    if lat is None or lon is None:
        return None
    try:
        alt = float(p[9]) if p[9] else 0.0
    except Exception:
        alt = 0.0
    return GGA(lat, lon, alt)
