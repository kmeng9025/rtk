
from vrs_engine.coords import lla_to_ecef
from vrs_engine.messages import encode_1005, decode_1005_1006, MsmObs, CellObs, encode_msm4, decode_msm
from vrs_engine.rtcm import message_type, payload_len, crc_ok

e=lla_to_ecef(40.1234567,-75.1234567,80.0)
f=encode_1005(999,e)
assert crc_ok(f) and message_type(f)==1005
c=decode_1005_1006(f[3:3+payload_len(f)],1005)
assert c and c.station_id==999
obs=MsmObs(1074,1074,999,123456789,0,[1,3],[2,24],{})
obs.cells[(1,2)]=CellObs(70.123456,70.123457,3,0,45)
obs.cells[(1,24)]=CellObs(70.123400,70.123460,3,0,40)
obs.cells[(3,2)]=CellObs(69.234567,69.234568,2,0,44)
g=encode_msm4(obs,999)
assert g and crc_ok(g) and message_type(g)==1074
d=decode_msm(g[3:3+payload_len(g)],1074)
assert d and len(d.cells)==3
print('roundtrip ok')
