
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, Optional, List
import time, math
from .bits import BitReader, BitWriter
from .rtcm import frame_payload
from .coords import ECEF

C_M_PER_MS = 299792.458

MSM_INPUT_TO_OUTPUT = {
    1074: 1074, 1077: 1074,
    1094: 1094, 1097: 1094,
    1124: 1124, 1127: 1124,
}
SUPPORTED_MSM = set(MSM_INPUT_TO_OUTPUT)

@dataclass
class StationCoord:
    station_id: int
    ecef: ECEF
    has_height: bool = False
    ant_height_m: float = 0.0

@dataclass
class CellObs:
    pseudorange_ms: float
    phase_ms: float
    lock: int = 0
    half_cycle: int = 0
    cnr_dbhz: float = 0.0
    phase_rate_mps: float = 0.0

@dataclass
class MsmObs:
    msg_type: int
    out_msg_type: int
    station_id: int
    epoch_ms: int
    multiple_message: int
    sats: List[int]
    sigs: List[int]
    cells: Dict[Tuple[int,int], CellObs] = field(default_factory=dict)
    recv_time: float = field(default_factory=time.time)

def decode_1005_1006(payload: bytes, msg_type: int) -> Optional[StationCoord]:
    try:
        br = BitReader(payload)
        mt = br.u(12)
        if mt not in (1005, 1006): return None
        sid = br.u(12)
        br.u(6); br.u(1); br.u(1); br.u(1); br.u(1)
        x = br.s(38) * 0.0001
        br.u(1); br.u(1)
        y = br.s(38) * 0.0001
        br.u(2)
        z = br.s(38) * 0.0001
        h = 0.0; has_h = False
        if mt == 1006 and br.remaining() >= 16:
            h = br.u(16) * 0.0001
            has_h = True
        return StationCoord(sid, ECEF(x,y,z), has_h, h)
    except Exception:
        return None

def encode_1005(station_id: int, ecef: ECEF) -> bytes:
    bw = BitWriter()
    bw.u(1005,12); bw.u(station_id & 0xFFF,12); bw.u(0,6)
    bw.u(1,1); bw.u(0,1); bw.u(1,1); bw.u(0,1)  # GPS, GLO, GAL flags; keep GLO 0 for our output
    bw.s(int(round(ecef.x/0.0001)),38)
    bw.u(0,1); bw.u(0,1)
    bw.s(int(round(ecef.y/0.0001)),38)
    bw.u(0,2)
    bw.s(int(round(ecef.z/0.0001)),38)
    return frame_payload(bw.bytes())

def _mask_indices(mask: int, nbits: int) -> List[int]:
    ids = []
    for i in range(nbits):
        if (mask >> (nbits-1-i)) & 1:
            ids.append(i+1)
    return ids

def decode_msm(payload: bytes, msg_type: int) -> Optional[MsmObs]:
    if msg_type not in SUPPORTED_MSM: return None
    try:
        br = BitReader(payload)
        mt = br.u(12)
        sid = br.u(12)
        epoch = br.u(30)
        multi = br.u(1)
        br.u(3); br.u(7); br.u(2); br.u(2); br.u(1); br.u(3)
        sat_mask = br.u(64); sig_mask = br.u(32)
        sats = _mask_indices(sat_mask,64); sigs = _mask_indices(sig_mask,32)
        nsat, nsig = len(sats), len(sigs)
        if not sats or not sigs: return None
        cell_pairs = []
        for sat in sats:
            for sig in sigs:
                if br.u(1): cell_pairs.append((sat,sig))
        level = msg_type % 10
        rough_int = {sat: br.u(8) for sat in sats}
        if level in (5,7):
            for sat in sats: br.u(4)
        rough_mod = {sat: br.u(10) for sat in sats}
        phase_rate = {sat: 0 for sat in sats}
        if level in (5,7):
            phase_rate = {sat: br.s(14) for sat in sats}
        cells: Dict[Tuple[int,int],CellObs] = {}
        if level in (4,5):
            fine_pr = [br.s(15) for _ in cell_pairs]
            fine_ph = [br.s(22) for _ in cell_pairs]
            locks = [br.u(4) for _ in cell_pairs]
            halfs = [br.u(1) for _ in cell_pairs]
            cnrs = [br.u(6) for _ in cell_pairs]
            for i,pair in enumerate(cell_pairs):
                sat,sig = pair
                ri = rough_int[sat]
                if ri == 255: continue
                if fine_pr[i] == -(1<<14) or fine_ph[i] == -(1<<21): continue
                rough = ri + rough_mod[sat]/1024.0
                cells[pair] = CellObs(
                    pseudorange_ms=rough + fine_pr[i]*(2.0**-24),
                    phase_ms=rough + fine_ph[i]*(2.0**-29),
                    lock=locks[i], half_cycle=halfs[i], cnr_dbhz=float(cnrs[i]), phase_rate_mps=float(phase_rate.get(sat,0))
                )
        elif level in (6,7):
            fine_pr = [br.s(20) for _ in cell_pairs]
            fine_ph = [br.s(24) for _ in cell_pairs]
            locks = [br.u(10) for _ in cell_pairs]
            halfs = [br.u(1) for _ in cell_pairs]
            cnrs = [br.u(10) for _ in cell_pairs]
            fine_rate = [br.s(15) for _ in cell_pairs]
            for i,pair in enumerate(cell_pairs):
                sat,sig = pair
                ri = rough_int[sat]
                if ri == 255: continue
                if fine_pr[i] == -(1<<19) or fine_ph[i] == -(1<<23): continue
                rough = ri + rough_mod[sat]/1024.0
                cells[pair] = CellObs(
                    pseudorange_ms=rough + fine_pr[i]*(2.0**-29),
                    phase_ms=rough + fine_ph[i]*(2.0**-31),
                    lock=locks[i], half_cycle=halfs[i], cnr_dbhz=cnrs[i]/16.0,
                    phase_rate_mps=float(phase_rate.get(sat,0)) + fine_rate[i]*0.0001
                )
        else:
            return None
        if not cells: return None
        return MsmObs(mt, MSM_INPUT_TO_OUTPUT[mt], sid, epoch, multi,
                      sorted({s for s,_ in cells}), sorted({g for _,g in cells}), cells)
    except Exception:
        return None

def _make_mask(ids: List[int], nbits: int) -> int:
    ids = set(ids); val = 0
    for i in range(nbits):
        val <<= 1
        if i+1 in ids: val |= 1
    return val

def _clip_signed(v: int, n: int) -> int:
    lo = -(1 << (n-1)) + 1
    hi = (1 << (n-1)) - 1
    return min(max(v, lo), hi)

def encode_msm4(obs: MsmObs, station_id: int = 999) -> Optional[bytes]:
    sats = sorted({s for s,_ in obs.cells})
    sigs = sorted({g for _,g in obs.cells})
    if not sats or not sigs: return None
    # Drop cells with phase-code separation too large for MSM4 fine phase range.
    valid_cells = {}
    for pair,c in obs.cells.items():
        if abs(c.phase_ms - c.pseudorange_ms) < 0.0036:  # about 1080 m
            valid_cells[pair] = c
    if not valid_cells: return None
    obs = MsmObs(obs.msg_type, obs.out_msg_type, station_id, obs.epoch_ms, 0,
                 sorted({s for s,_ in valid_cells}), sorted({g for _,g in valid_cells}), valid_cells, obs.recv_time)
    sats = obs.sats; sigs = obs.sigs
    pairs = [(s,g) for s in sats for g in sigs if (s,g) in obs.cells]
    bw = BitWriter()
    bw.u(obs.out_msg_type,12); bw.u(station_id & 0xFFF,12)
    bw.u(int(obs.epoch_ms) & ((1<<30)-1),30)
    bw.u(0,1); bw.u(0,3); bw.u(0,7); bw.u(0,2); bw.u(0,2); bw.u(0,1); bw.u(0,3)
    bw.u(_make_mask(sats,64),64); bw.u(_make_mask(sigs,32),32)
    for s in sats:
        for g in sigs:
            bw.u(1 if (s,g) in obs.cells else 0,1)
    rough_int = {}; rough_mod = {}; rough_ms = {}
    for sat in sats:
        vals = [obs.cells[(sat,g)].pseudorange_ms for g in sigs if (sat,g) in obs.cells]
        ref = vals[0]
        ri = int(math.floor(max(ref,0.0)))
        if ri >= 255: ri = 254
        rem = ref - ri
        rm = int(round(rem * 1024.0))
        if rm >= 1024:
            rm = 0; ri = min(ri+1,254)
        rough_int[sat] = ri; rough_mod[sat] = rm; rough_ms[sat] = ri + rm/1024.0
    for sat in sats: bw.u(rough_int[sat],8)
    for sat in sats: bw.u(rough_mod[sat],10)
    fine_pr=[]; fine_ph=[]; locks=[]; halfs=[]; cnrs=[]
    for p in pairs:
        sat,_sig = p; c=obs.cells[p]; rough=rough_ms[sat]
        fine_pr.append(_clip_signed(int(round((c.pseudorange_ms-rough)/(2.0**-24))),15))
        fine_ph.append(_clip_signed(int(round((c.phase_ms-rough)/(2.0**-29))),22))
        locks.append(min(max(int(c.lock),0),15)); halfs.append(1 if c.half_cycle else 0); cnrs.append(min(max(int(round(c.cnr_dbhz)),0),63))
    for v in fine_pr: bw.s(v,15)
    for v in fine_ph: bw.s(v,22)
    for v in locks: bw.u(v,4)
    for v in halfs: bw.u(v,1)
    for v in cnrs: bw.u(v,6)
    return frame_payload(bw.bytes())
