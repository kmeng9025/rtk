
from __future__ import annotations
import argparse, threading, queue, time
from pathlib import Path
import yaml
from .coords import ECEF, LLA, lla_to_ecef
from .rtcm import RtcmFramer
from .ntrip import NtripClient, NtripConfig
from .messages import decode_1005_1006, decode_msm, encode_1005, encode_msm4, SUPPORTED_MSM
from .combiner import VrsCombiner, EngineConfig
from .output import OutputBus, SimpleNtripCaster

class Event:
    def __init__(self, base, kind, data): self.base=base; self.kind=kind; self.data=data

def load_yaml(path):
    with open(path,'r',encoding='utf-8') as f: return yaml.safe_load(f)

def input_worker(base_cfg, global_cfg, q, output_dir: Path):
    ncfg=NtripConfig(base_cfg['name'],base_cfg['host'],int(base_cfg.get('port',2101)),base_cfg['mountpoint'],str(base_cfg.get('username','') or ''),str(base_cfg.get('password','') or ''),bool(base_cfg.get('send_gga',False)))
    client=NtripClient(ncfg, rover_gga=global_cfg.get('input_ntrip',{}).get('rover_gga','') or '', reconnect_delay=float(global_cfg.get('input_ntrip',{}).get('reconnect_delay_sec',3)))
    framer=RtcmFramer(validate_crc=True); output_dir.mkdir(parents=True,exist_ok=True)
    log_path=output_dir/f"{ncfg.name}_{time.strftime('%Y%m%d_%H%M%S')}.rtcm3"
    q.put(Event(ncfg.name,'log',str(log_path)))
    with open(log_path,'ab',buffering=0) as logf:
        for chunk in client.chunks_forever():
            logf.write(chunk); q.put(Event(ncfg.name,'bytes',len(chunk)))
            frames=framer.push(chunk)
            if framer.crc_bad: q.put(Event(ncfg.name,'crc_bad',framer.crc_bad)); framer.crc_bad=0
            if framer.discarded: q.put(Event(ncfg.name,'discarded',framer.discarded)); framer.discarded=0
            for fr in frames: q.put(Event(ncfg.name,'frame',fr))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',required=True); args=ap.parse_args()
    cfg=load_yaml(args.config); outdir=Path(cfg.get('output_dir','logs')); outdir.mkdir(parents=True,exist_ok=True)
    vcfg=cfg.get('virtual',{})
    virtual_lla=LLA(float(vcfg['lat_deg']),float(vcfg['lon_deg']),float(vcfg.get('h_m',0.0)))
    eraw=cfg.get('engine',{})
    mode=str(eraw.get('mode','vrs_plane'))
    signal_whitelist={int(k):set(int(x) for x in v) for k,v in (eraw.get('signal_whitelist',{}) or {}).items()}
    ecfg=EngineConfig(master_base=eraw.get('master_base','base_a'), min_bases=int(eraw.get('min_bases',2)), max_obs_age_sec=float(eraw.get('max_obs_age_sec',2.5)), max_epoch_diff_ms=int(eraw.get('max_epoch_diff_ms',1200)), spatial_model=str(eraw.get('spatial_model','plane')), idw_power=float(eraw.get('idw_power',2.0)), phase_offset_alpha=float(eraw.get('phase_offset_alpha',0.02)), phase_offset_reset_threshold_ms=float(eraw.get('phase_offset_reset_threshold_ms',0.0001)), signal_whitelist=signal_whitelist)
    enabled_types=set(int(x) for x in eraw.get('enabled_message_types',list(SUPPORTED_MSM)))
    passthrough_base=str(eraw.get('passthrough_base',ecfg.master_base))
    emit_1005_interval=float(eraw.get('emit_1005_interval_sec',5))
    combiner=VrsCombiner(ecfg,virtual_lla)
    bus=OutputBus(); synth_log=outdir/f"synthetic_vrs_{time.strftime('%Y%m%d_%H%M%S')}.rtcm3"; bus.attach_file(str(synth_log))
    print(f'[output] stream log: {synth_log}', flush=True)
    serial_cfg=cfg.get('output',{}).get('serial',{}) or {}
    if serial_cfg.get('enabled',False): bus.attach_serial(serial_cfg['port'],int(serial_cfg.get('baud',115200))); print(f"[output] serial {serial_cfg['port']} @ {serial_cfg.get('baud',115200)}", flush=True)
    def on_rover_gga(gga):
        if vcfg.get('mode','fixed') == 'from_rover_gga':
            lla=LLA(gga.lat_deg,gga.lon_deg,gga.alt_m); combiner.set_virtual_lla(lla); print(f'[virtual] GGA {lla.lat_deg:.8f},{lla.lon_deg:.8f},{lla.h_m:.1f}', flush=True)
    caster_cfg=cfg.get('output',{}).get('ntrip_caster',{}) or {}
    if caster_cfg.get('enabled',True):
        SimpleNtripCaster(caster_cfg.get('host','0.0.0.0'),int(caster_cfg.get('port',2102)),caster_cfg.get('mountpoint','VRS'),bus,on_rover_gga).start()
    q=queue.Queue()
    # fallback coords
    for b in cfg.get('bases',[]):
        if all(k in b for k in ('ecef_x_m','ecef_y_m','ecef_z_m')):
            combiner.update_base_coord(b['name'], ECEF(float(b['ecef_x_m']),float(b['ecef_y_m']),float(b['ecef_z_m'])), 0)
            print(f"[{b['name']}] using configured ECEF", flush=True)
    for b in cfg.get('bases',[]):
        threading.Thread(target=input_worker,args=(b,cfg,q,outdir),daemon=True).start()
    stats={}; outputs=0; last_status=0.0; last_1005=0.0
    def emit_1005(): bus.publish(encode_1005(999,combiner.virtual_ecef))
    emit_1005()
    while True:
        try: ev=q.get(timeout=0.5)
        except queue.Empty: ev=None
        now=time.time()
        if mode!='passthrough' and now-last_1005 >= emit_1005_interval:
            emit_1005(); last_1005=now
        if ev:
            st=stats.setdefault(ev.base,{'bytes':0,'frames':0,'crc':0,'disc':0,'coord':False,'msm':{}})
            if ev.kind=='log': print(f'[{ev.base}] logging {ev.data}', flush=True)
            elif ev.kind=='bytes': st['bytes']+=int(ev.data)
            elif ev.kind=='crc_bad': st['crc']+=int(ev.data)
            elif ev.kind=='discarded': st['disc']+=int(ev.data)
            elif ev.kind=='frame':
                fr=ev.data; st['frames']+=1
                if mode=='passthrough' and ev.base==passthrough_base:
                    bus.publish(fr.raw); outputs+=1
                if fr.msg_type in (1005,1006):
                    c=decode_1005_1006(fr.payload,fr.msg_type)
                    if c: combiner.update_base_coord(ev.base,c.ecef,c.station_id); st['coord']=True
                if fr.msg_type in enabled_types:
                    obs=decode_msm(fr.payload,fr.msg_type)
                    if obs:
                        combiner.update_obs(ev.base,obs); st['msm'][obs.out_msg_type]=st['msm'].get(obs.out_msg_type,0)+1
                        if mode=='vrs_plane' and ev.base==ecfg.master_base:
                            syn=combiner.synthesize_for_type(obs.out_msg_type)
                            if syn:
                                out=encode_msm4(syn,999)
                                if out: bus.publish(out); outputs+=1
        if now-last_status > 5:
            print('\n--- VRS status ---', flush=True)
            print(f"mode={mode} virtual={combiner.virtual_lla.lat_deg:.8f},{combiner.virtual_lla.lon_deg:.8f},{combiner.virtual_lla.h_m:.1f} outputs={outputs} offset_resets={combiner.offset_resets}", flush=True)
            print(f"signal_ids={combiner.signal_ids_seen()}", flush=True)
            if combiner.last_warning: print(f"warning={combiner.last_warning}", flush=True)
            for name,st in sorted(stats.items()):
                bstate=combiner.bases.get(name); has_coord=(bstate is not None and bstate.ecef is not None)
                print(f"{name}: bytes={st['bytes']} frames={st['frames']} crc_bad={st['crc']} disc={st['disc']} coord={has_coord} msm={st['msm']}", flush=True)
            last_status=now
if __name__=='__main__': main()
