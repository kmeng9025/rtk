
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, List

CRC24Q_POLY = 0x1864CFB

def crc24q(data: bytes) -> int:
    crc = 0
    for b in data:
        crc ^= b << 16
        for _ in range(8):
            crc <<= 1
            if crc & 0x1000000:
                crc ^= CRC24Q_POLY
            crc &= 0xFFFFFF
    return crc & 0xFFFFFF

def frame_payload(payload: bytes) -> bytes:
    if len(payload) > 1023:
        raise ValueError('RTCM payload too long')
    h = bytes([0xD3, (len(payload) >> 8) & 0x03, len(payload) & 0xFF])
    body = h + payload
    return body + crc24q(body).to_bytes(3, 'big')

def payload_len(frame: bytes) -> int:
    return ((frame[1] & 0x03) << 8) | frame[2]

def message_type(frame: bytes) -> Optional[int]:
    if len(frame) < 6 or frame[0] != 0xD3:
        return None
    l = payload_len(frame)
    if len(frame) < 3 + l + 3 or l < 2:
        return None
    p = frame[3:3+l]
    return (p[0] << 4) | (p[1] >> 4)

def crc_ok(frame: bytes) -> bool:
    if len(frame) < 6 or frame[0] != 0xD3:
        return False
    l = payload_len(frame)
    total = 3 + l + 3
    if len(frame) != total:
        return False
    return int.from_bytes(frame[-3:], 'big') == crc24q(frame[:-3])

@dataclass
class RtcmFrame:
    raw: bytes
    payload: bytes
    msg_type: int

class RtcmFramer:
    def __init__(self, validate_crc: bool = True):
        self.buf = bytearray()
        self.validate_crc = validate_crc
        self.crc_bad = 0
        self.discarded = 0
    def push(self, data: bytes) -> List[RtcmFrame]:
        self.buf.extend(data)
        out = []
        while True:
            idx = self.buf.find(b'\xD3')
            if idx < 0:
                self.discarded += len(self.buf)
                self.buf.clear()
                break
            if idx > 0:
                del self.buf[:idx]
                self.discarded += idx
            if len(self.buf) < 3:
                break
            if self.buf[1] & 0xFC:
                del self.buf[0]
                self.discarded += 1
                continue
            l = ((self.buf[1] & 0x03) << 8) | self.buf[2]
            total = 3 + l + 3
            if l == 0 or l > 1023:
                del self.buf[0]
                self.discarded += 1
                continue
            if len(self.buf) < total:
                break
            raw = bytes(self.buf[:total])
            del self.buf[:total]
            if self.validate_crc and not crc_ok(raw):
                self.crc_bad += 1
                continue
            mt = message_type(raw)
            if mt is not None:
                out.append(RtcmFrame(raw, raw[3:3+l], mt))
        return out
