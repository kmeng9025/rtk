
from __future__ import annotations
import queue, socket, threading
from typing import Optional, Callable
from .nmea import parse_gga
try:
    import serial
except Exception:
    serial = None

class OutputBus:
    def __init__(self, max_backlog: int = 5000):
        self.clients=[]; self.lock=threading.Lock(); self.max_backlog=max_backlog; self.file=None; self.serial=None
    def attach_file(self,path: str): self.file=open(path,'ab',buffering=0)
    def attach_serial(self, port: str, baud: int):
        if serial is None: raise RuntimeError('pyserial not installed')
        self.serial = serial.Serial(port, baudrate=baud, timeout=0)
    def new_client_queue(self):
        q=queue.Queue(maxsize=self.max_backlog)
        with self.lock: self.clients.append(q)
        return q
    def remove_client_queue(self,q):
        with self.lock:
            if q in self.clients: self.clients.remove(q)
    def publish(self,data: bytes):
        if not data: return
        if self.file: self.file.write(data)
        if self.serial: self.serial.write(data)
        with self.lock:
            dead=[]
            for q in self.clients:
                try: q.put_nowait(data)
                except queue.Full: dead.append(q)
            for q in dead:
                if q in self.clients: self.clients.remove(q)

class SimpleNtripCaster(threading.Thread):
    def __init__(self, host: str, port: int, mountpoint: str, bus: OutputBus, gga_callback: Optional[Callable] = None):
        super().__init__(daemon=True); self.host=host; self.port=int(port); self.mountpoint=mountpoint.strip('/'); self.bus=bus; self.gga_callback=gga_callback
    def run(self):
        srv=socket.socket(socket.AF_INET,socket.SOCK_STREAM); srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        srv.bind((self.host,self.port)); srv.listen(5)
        print(f'[caster] listening on {self.host}:{self.port}/{self.mountpoint}', flush=True)
        while True:
            c,a=srv.accept(); threading.Thread(target=self.handle_client,args=(c,a),daemon=True).start()
    def handle_client(self,conn: socket.socket, addr):
        q=self.bus.new_client_queue()
        try:
            conn.settimeout(2.0); header=bytearray()
            while b'\r\n\r\n' not in header and len(header)<8192:
                b=conn.recv(1)
                if not b: break
                header.extend(b)
            conn.sendall(b'ICY 200 OK\r\n\r\n')
            conn.settimeout(0.01)
            def reader():
                buf=bytearray()
                while True:
                    try: data=conn.recv(1024)
                    except socket.timeout: continue
                    except Exception: return
                    if not data: return
                    buf.extend(data)
                    while b'\n' in buf:
                        line,_,rest=buf.partition(b'\n'); buf[:]=rest
                        gga=parse_gga(line.decode('ascii',errors='ignore').strip())
                        if gga and self.gga_callback: self.gga_callback(gga)
            threading.Thread(target=reader,daemon=True).start()
            print(f'[caster] client {addr} connected', flush=True)
            while True: conn.sendall(q.get())
        except Exception as e:
            print(f'[caster] client {addr} disconnected: {e}', flush=True)
        finally:
            self.bus.remove_client_queue(q)
            try: conn.close()
            except Exception: pass
