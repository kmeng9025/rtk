
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, Optional, List
import math, time
from .coords import ECEF, LLA, ecef_to_enu, lla_to_ecef
from .messages import MsmObs, CellObs

@dataclass
class BaseState:
    name: str
    ecef: Optional[ECEF] = None
    station_id: int = 0
    last_obs: Dict[int, MsmObs] = field(default_factory=dict)

@dataclass
class EngineConfig:
    master_base: str
    min_bases: int = 2
    max_obs_age_sec: float = 2.5
    max_epoch_diff_ms: int = 1200
    spatial_model: str = 'plane'
    idw_power: float = 2.0
    phase_offset_alpha: float = 0.02
    phase_offset_reset_threshold_ms: float = 0.0001
    signal_whitelist: Dict[int, set] = field(default_factory=dict)

class VrsCombiner:
    def __init__(self, cfg: EngineConfig, virtual_lla: LLA):
        self.cfg=cfg; self.virtual_lla=virtual_lla; self.virtual_ecef=lla_to_ecef(virtual_lla.lat_deg, virtual_lla.lon_deg, virtual_lla.h_m)
        self.bases: Dict[str,BaseState]={}
        self.phase_offsets: Dict[Tuple[int,int,int,str], float] = {}
        self.offset_resets=0
        self.last_warning=''
    def set_virtual_lla(self, lla: LLA):
        self.virtual_lla=lla; self.virtual_ecef=lla_to_ecef(lla.lat_deg,lla.lon_deg,lla.h_m)
    def update_base_coord(self,name: str,ecef: ECEF,station_id: int=0):
        st=self.bases.setdefault(name,BaseState(name)); st.ecef=ecef
        if station_id: st.station_id=station_id
    def update_obs(self,name: str, obs: MsmObs):
        st=self.bases.setdefault(name,BaseState(name)); st.last_obs[obs.out_msg_type]=obs
    def signal_ids_seen(self):
        out={}
        for st in self.bases.values():
            for mt,obs in st.last_obs.items():
                out.setdefault(mt,set()).update(obs.sigs)
        return {k:sorted(v) for k,v in out.items()}
    def _base_enu(self, names: List[str]) -> Dict[str,tuple[float,float,float]]:
        out={}
        for n in names:
            e=self.bases[n].ecef
            if e is not None: out[n]=ecef_to_enu(e,self.virtual_lla)
        return out
    def _idw(self, vals: Dict[str,float], enu: Dict[str,tuple[float,float,float]]) -> float:
        weights={}
        for n,v in vals.items():
            e,no,_=enu[n]; d=max(math.hypot(e,no),1.0); weights[n]=1.0/(d**self.cfg.idw_power)
        s=sum(weights.values())
        return sum(weights[n]/s*vals[n] for n in vals)
    def _solve3(self,A,b):
        # Gaussian elimination 3x3
        m=[A[0][:]+[b[0]], A[1][:]+[b[1]], A[2][:]+[b[2]]]
        for i in range(3):
            piv=max(range(i,3), key=lambda r: abs(m[r][i]))
            if abs(m[piv][i]) < 1e-12: raise ValueError('singular')
            if piv!=i: m[i],m[piv]=m[piv],m[i]
            p=m[i][i]
            for j in range(i,4): m[i][j]/=p
            for r in range(3):
                if r==i: continue
                f=m[r][i]
                for j in range(i,4): m[r][j]-=f*m[i][j]
        return [m[i][3] for i in range(3)]
    def _plane_predict_at_origin(self, vals: Dict[str,float], enu: Dict[str,tuple[float,float,float]]) -> float:
        if len(vals) < 3:
            return self._idw(vals,enu)
        # Weighted LS: y = a + b*east + c*north. Predict at virtual station e=n=0 => a.
        # Scale ENU to km for conditioning.
        N=[[0.0]*3 for _ in range(3)]; rhs=[0.0]*3
        for n,y in vals.items():
            e,no,_=enu[n]
            x=[1.0, e/1000.0, no/1000.0]
            d=max(math.hypot(e,no),1.0)
            w=1.0/(d**0.5)  # mild weighting; plane needs geometry more than inverse-square dominance
            for i in range(3):
                rhs[i]+=w*x[i]*y
                for j in range(3): N[i][j]+=w*x[i]*x[j]
        try:
            beta=self._solve3(N,rhs)
            return beta[0]
        except Exception:
            return self._idw(vals,enu)
    def _predict(self, vals: Dict[str,float], enu: Dict[str,tuple[float,float,float]]) -> float:
        if self.cfg.spatial_model == 'plane': return self._plane_predict_at_origin(vals,enu)
        return self._idw(vals,enu)
    def _eligible_bases(self, out_msg_type: int, master_obs: MsmObs) -> List[str]:
        now=time.time(); out=[]
        for name,st in self.bases.items():
            if st.ecef is None: continue
            obs=st.last_obs.get(out_msg_type)
            if obs is None: continue
            if now - obs.recv_time > self.cfg.max_obs_age_sec: continue
            if abs(int(obs.epoch_ms)-int(master_obs.epoch_ms)) > self.cfg.max_epoch_diff_ms: continue
            out.append(name)
        return out
    def _aligned_phase(self, out_msg_type: int, sat: int, sig: int, base_name: str, cell: CellObs, master_cell: CellObs) -> float:
        if base_name == self.cfg.master_base:
            return cell.phase_ms
        key=(out_msg_type,sat,sig,base_name)
        current=(cell.phase_ms-cell.pseudorange_ms) - (master_cell.phase_ms-master_cell.pseudorange_ms)
        old=self.phase_offsets.get(key)
        if old is None or abs(current-old) > self.cfg.phase_offset_reset_threshold_ms:
            self.phase_offsets[key]=current; self.offset_resets+=1
        else:
            a=self.cfg.phase_offset_alpha
            self.phase_offsets[key]=(1-a)*old + a*current
        return cell.phase_ms - self.phase_offsets[key]
    def synthesize_for_type(self,out_msg_type: int) -> Optional[MsmObs]:
        self.last_warning=''
        master=self.bases.get(self.cfg.master_base)
        if master is None: return None
        master_obs=master.last_obs.get(out_msg_type)
        if master_obs is None: return None
        names=self._eligible_bases(out_msg_type, master_obs)
        if self.cfg.master_base not in names: return None
        if len(names) < self.cfg.min_bases:
            self.last_warning=f'not enough bases for {out_msg_type}: {len(names)}'
            return None
        enu=self._base_enu(names)
        all_cells=set()
        for n in names: all_cells |= set(self.bases[n].last_obs[out_msg_type].cells.keys())
        wl=self.cfg.signal_whitelist.get(out_msg_type,set())
        out_cells={}
        for pair in sorted(all_cells):
            sat,sig=pair
            if wl and sig not in wl: continue
            if pair not in master_obs.cells: continue
            avail=[n for n in names if pair in self.bases[n].last_obs[out_msg_type].cells]
            if len(avail) < self.cfg.min_bases: continue
            master_cell=master_obs.cells[pair]
            vals_pr={}; vals_ph={}; cnr_vals=[]; lock=master_cell.lock
            for n in avail:
                c=self.bases[n].last_obs[out_msg_type].cells[pair]
                vals_pr[n]=c.pseudorange_ms
                vals_ph[n]=self._aligned_phase(out_msg_type,sat,sig,n,c,master_cell)
                cnr_vals.append(c.cnr_dbhz); lock=min(lock,c.lock)
            pr_v=self._predict(vals_pr,enu)
            ph_v=self._predict(vals_ph,enu)
            # Safety: phase range must stay near code range for MSM4. If plane phase drifts too far, pull it near code while preserving master bias.
            if abs(ph_v-pr_v) > 0.0032:
                ph_v = pr_v + (master_cell.phase_ms-master_cell.pseudorange_ms)
            out_cells[pair]=CellObs(pr_v,ph_v,lock=lock,half_cycle=master_cell.half_cycle,cnr_dbhz=sum(cnr_vals)/len(cnr_vals),phase_rate_mps=master_cell.phase_rate_mps)
        if not out_cells: return None
        return MsmObs(out_msg_type,out_msg_type,999,master_obs.epoch_ms,0,sorted({s for s,_ in out_cells}),sorted({g for _,g in out_cells}),out_cells)
