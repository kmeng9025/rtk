
# Experimental DIY VRS Engine v0.3

This package is a much stronger version of the first prototype.

It creates a **single synthetic RTCM correction stream** from multiple base stations. It is still not professional VRS, but it now does the upgrades needed after seeing your receiver stay in DGNSS:

- adds raw passthrough mode for control testing
- uses base coordinates instead of simply averaging observations
- fits a local spatial plane for each satellite/signal observation
- predicts the observation at the virtual station position
- smooths phase-code ambiguity offsets before carrier-phase alignment
- outputs one virtual reference station: 1005 + synthetic MSM4
- includes signal-ID diagnostics so you can see if your base is giving L1/L2 vs L1/L5-compatible signals

## Install

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
copy config.example.yaml config.yaml
```

Linux / Raspberry Pi:

```bash
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp config.example.yaml config.yaml
```

## Test 1: passthrough mode first

Before testing fake VRS, prove the same local caster path can produce RTK float/fix using a real base.

In `config.yaml`:

```yaml
engine:
  mode: passthrough
  passthrough_base: base_a
```

Run:

```bash
python -m vrs_engine.main --config config.yaml
```

Connect your LC29HEA to:

```text
host: computer_or_pi_ip
port: 2102
mountpoint: VRS
username/password: blank
```

If passthrough does not reach RTK float/fix, the problem is not VRS math. It is likely base distance/signal compatibility/receiver config/serial injection.

## Test 2: VRS plane mode

Switch:

```yaml
engine:
  mode: vrs_plane
  master_base: base_a
  min_bases: 2
  spatial_model: plane
```

Run again.

Good status looks like:

```text
--- VRS status ---
outputs=123
base_a: coord=True msm={1074:..., 1094:..., 1124:...}
base_b: coord=True msm={1074:..., 1094:...}
base_c: coord=True msm={1074:..., 1094:..., 1124:...}
signal_ids={1074:[2,24],1094:[2,19],1124:[2,...]}
```

If a base says `coord=False`, either wait longer or manually add its ECEF coordinates in the config.

## If rover stays DGNSS

Try these in order:

1. Make sure passthrough reaches FLOAT/FIX.
2. Use only two best bases: `min_bases: 2`.
3. Put `virtual.lat/lon/h` close to the rover.
4. Make sure all usable bases have `coord=True`.
5. Try `master_base` as the base that performs best in passthrough.
6. Watch signal IDs. If your LC29HEA is L1+L5 and the bases only give L1/L2, RTK may remain weak.
7. Try `phase_offset_alpha: 0.01` for more stability or `0.05` for faster convergence.

## Modes

### passthrough

Sends one raw base stream through your local caster. This confirms networking/caster/receiver pipeline.

### vrs_plane

Creates synthetic virtual-base observations with:

```text
base observations + base coordinates
→ local plane fit per sat/signal
→ predicted virtual-base pseudorange
→ smoothed phase alignment
→ synthetic MSM4 RTCM
```

## Limitations

This still is not commercial VRS. It does not yet use broadcast ephemeris to compute exact satellite ECEF positions. Instead, it uses the bases themselves to estimate local geometry as a plane. This can work surprisingly well for small triangles, but it may fail if:

- bases are far apart
- virtual point is outside the triangle
- bases have different signals
- base streams have poor carrier phase continuity
- LC29HEA cannot use the signals being transmitted

## Helpful external tools

Use RTKLIB `str2str`, `convbin`, or BKG BNC to record and inspect the generated stream.

Example:

```bash
str2str -in ntrip://127.0.0.1:2102/VRS -out file://synthetic_vrs.rtcm3
convbin synthetic_vrs.rtcm3 -r rtcm3 -o synthetic_vrs.obs
```
